<template>
  <div class="home-container">
    <h1>Bienvenido al Home</h1>
    <div v-if="isAuthenticated">
      <p>Selecciona una opción:</p>
      <router-link to="/inventario" class="home-link">Ver Inventario</router-link>
      <router-link to="/tabla-inventario" class="home-link">Ver Tabla Inventario</router-link>
    </div>
    <button @click="logout" class="logout-button">Cerrar sesión</button>
  </div>
</template>

<script>
import { useAuthStore } from '../stores/authStore';  // Importamos el store

export default {
  computed: {
    isAuthenticated() {
      const authStore = useAuthStore();
      return authStore.isAuthenticated;
    }
  },
  methods: {
    logout() {
      const authStore = useAuthStore();
      authStore.logout();
      this.$router.push('/'); // Redirige al login
    }
  }
}
</script>

<style scoped>
.home-container {
  text-align: center;
  padding: 20px;
}

.home-link {
  text-decoration: none;
  font-size: 1.2rem;
  color: #2196F3;
  border: 2px solid #2196F3;
  padding: 10px 20px;
  border-radius: 5px;
  margin: 10px;
  transition: background-color 0.3s ease, color 0.3s ease;
}

.home-link:hover {
  background-color: #2196F3;
  color: white;
}

.logout-button {
  margin-top: 20px;
  padding: 10px 20px;
  background-color: #FF5722;
  color: white;
  border: none;
  cursor: pointer;
}

.logout-button:hover {
  background-color: #E64A19;
}
</style>
