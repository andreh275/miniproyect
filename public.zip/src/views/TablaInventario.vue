<template>
  <div>
    <h2>Inventario</h2>
    <button @click="addProduct">Agregar Producto</button>
    <table>
      <thead>
        <tr>
          <th>Producto</th>
          <th>Cantidad</th>
          <th>Precio</th>
          <th>Acciones</th>
        </tr>
      </thead>
      <tbody>
        <tr v-for="(product, index) in products" :key="index">
          <td>{{ product.name }}</td>
          <td>{{ product.quantity }}</td>
          <td>{{ product.price }}</td>
          <td><button @click="editProduct(index)">Editar</button></td>
        </tr>
      </tbody>
    </table>
    <div v-if="isEditing">
      <h3>{{ editIndex === null ? 'Agregar Producto' : 'Editar Producto' }}</h3>
      <input v-model="newProduct.name" placeholder="Nombre" />
      <input v-model="newProduct.quantity" type="number" placeholder="Cantidad" />
      <input v-model="newProduct.price" type="number" placeholder="Precio" />
      <button @click="saveProduct">{{ editIndex === null ? 'Agregar' : 'Guardar' }}</button>
      <button @click="cancelEdit">Cancelar</button>
    </div>
  </div>
</template>

<script>
export default {
  data() {
    return {
      products: [],
      newProduct: { name: '', quantity: 0, price: 0 },
      isEditing: false,
      editIndex: null,
    };
  },
  methods: {
    addProduct() {
      this.isEditing = true;
      this.editIndex = null;
      this.newProduct = { name: '', quantity: 0, price: 0 };
    },
    editProduct(index) {
      this.isEditing = true;
      this.editIndex = index;
      this.newProduct = { ...this.products[index] };
    },
    saveProduct() {
      if (this.editIndex === null) {
        this.products.push({ ...this.newProduct });
      } else {
        this.products[this.editIndex] = { ...this.newProduct };
      }
      this.isEditing = false;
    },
    cancelEdit() {
      this.isEditing = false;
      this.editIndex = null;
    }
  }
}
</script>

<style scoped>
table {
  width: 100%;
  border-collapse: collapse;
}
th, td {
  padding: 10px;
  border: 1px solid #ddd;
}
button {
  padding: 5px 10px;
  margin: 5px;
  background-color: #4CAF50;
  color: white;
  border: none;
  cursor: pointer;
}
</style>
