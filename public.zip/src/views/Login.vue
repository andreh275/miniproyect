<template>
  <div class="login-container">
    <h1>Iniciar sesión</h1>
    <form @submit.prevent="handleLogin">
      <div class="input-container">
        <label for="username">Usuario:</label>
        <input type="text" id="username" v-model="username" required />
      </div>
      <div class="input-container">
        <label for="password">Contraseña:</label>
        <input type="password" id="password" v-model="password" required />
      </div>
      <button type="submit" class="login-button">Iniciar sesión</button>
    </form>
  </div>
</template>

<script>
import { useAuthStore } from '../stores/authStore';

export default {
  data() {
    return {
      username: '',
      password: ''
    };
  },
  methods: {
    handleLogin() {
      // Comprobamos las credenciales
      if (this.username === 'admin' && this.password === '1234') {
        // Usamos el store de Pinia para actualizar el estado de autenticación
        const authStore = useAuthStore();
        authStore.login();
        this.$router.push('/Home'); // Redirige a /home
      } else {
        alert('Credenciales inválidas');
      }
    }
  }
};
</script>

<style scoped>
.login-container {
  max-width: 400px;
  margin: 0 auto;
  padding: 20px;
  text-align: center;
}

.input-container {
  margin-bottom: 10px;
}

input {
  width: 100%;
  padding: 10px;
  margin-top: 5px;
}

button {
  padding: 10px 20px;
  background-color: #2196F3;
  color: white;
  border: none;
  cursor: pointer;
  width: 100%;
}

button:hover {
  background-color: #1976D2;
}
</style>
