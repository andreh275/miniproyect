import { createRouter, createWebHistory } from 'vue-router';
import { useAuthStore } from '../stores/authStore';  // Importamos el store
import Login from '../views/Login.vue';
import Home from '../views/Home.vue';
import Inventario from '../views/Inventario.vue';
import TablaInventario from '../views/TablaInventario.vue';

const routes = [
  {
    path: '/',
    name: 'login',
    component: Login
  },
  {
    path: '/home',
    name: 'home',
    component: Home,
    beforeEnter: (to, from, next) => {
      const authStore = useAuthStore();
      if (authStore.isAuthenticated) {
        next();  // Si está autenticado, permite el acceso
      } else {
        next('/');  // Si no está autenticado, redirige al login
      }
    }
  },
  {
    path: '/inventario',
    name: 'inventario',
    component: Inventario,
    beforeEnter: (to, from, next) => {
      const authStore = useAuthStore();
      if (authStore.isAuthenticated) {
        next();
      } else {
        next('/');  // Redirige si no está autenticado
      }
    }
  },
  {
    path: '/tabla-inventario',
    name: 'tabla-inventario',
    component: TablaInventario,
    beforeEnter: (to, from, next) => {
      const authStore = useAuthStore();
      if (authStore.isAuthenticated) {
        next();
      } else {
        next('/');  // Redirige si no está autenticado
      }
    }
  }
];

const router = createRouter({
  history: createWebHistory(),
  routes
});

export default router;
